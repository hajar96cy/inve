from sqlalchemy import Column, Integer, Float, DateTime, ForeignKey, String
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from database import Base

class Sale(Base):
    __tablename__ = 'sales'
    
    id = Column(Integer, primary_key=True)
    product_id = Column(Integer, ForeignKey('products.id'), nullable=False)
    client_id = Column(Integer, ForeignKey('clients.id'), nullable=True)
    quantity = Column(Integer, nullable=False)
    price = Column(Float, nullable=False)
    total = Column(Float, nullable=False)
    date = Column(DateTime, default=func.now())
    status = Column(String(20), default='completed')  # completed, pending, cancelled
    
    product = relationship('Product', backref='sales')
    client = relationship('Client', backref='sales')
    
    def __repr__(self):
        return f'<Sale {self.id}>'
