from sqlalchemy import Column, Integer, String, Float, DateTime
from sqlalchemy.sql import func
from database import Base

class Client(Base):
    __tablename__ = 'clients'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    phone = Column(String(20))
    address = Column(String(200))
    email = Column(String(100))
    total_spent = Column(Float, default=0.0)
    created_at = Column(DateTime, default=func.now())
    
    def __repr__(self):
        return f'<Client {self.name}>'
