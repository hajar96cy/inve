from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text
from sqlalchemy.sql import func
from database import Base

class Notification(Base):
    __tablename__ = 'notifications'
    
    id = Column(Integer, primary_key=True)
    title = Column(String(100), nullable=False)
    message = Column(Text, nullable=False)
    type = Column(String(20), default='info')  # info, warning, danger, success
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=func.now())
    
    def __repr__(self):
        return f'<Notification {self.title}>'
    
    @classmethod
    def create(cls, title, message, type='info'):
        from database import db_session
        notification = cls(title=title, message=message, type=type)
        db_session.add(notification)
        db_session.commit()
        return notification
