from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required
from models.sale import Sale
from models.client import Client
from database import db_session
from datetime import datetime, timedelta
from config import Config

commandes_bp = Blueprint('commandes', __name__, url_prefix='/commandes')

@commandes_bp.route('/')
@login_required
def index():
    # Regrouper les ventes par date et client pour former des "commandes"
    sales = Sale.query.order_by(Sale.date.desc()).all()
    
    # Créer un dictionnaire pour regrouper les ventes
    orders = {}
    for sale in sales:
        # Clé: date + client_id (ou "guest" si pas de client)
        key = f"{sale.date.strftime('%Y-%m-%d')}_{sale.client_id or 'guest'}"
        
        if key not in orders:
            orders[key] = {
                'id': key,
                'date': sale.date,
                'client': sale.client.name if sale.client else "Client anonyme",
                'client_id': sale.client_id,
                'items': [],
                'total': 0
            }
        
        orders[key]['items'].append({
            'product': sale.product.name,
            'quantity': sale.quantity,
            'price': sale.price,
            'total': sale.total
        })
        
        orders[key]['total'] += sale.total
    
    # Convertir le dictionnaire en liste
    orders_list = list(orders.values())
    
    return render_template('commandes.html', orders=orders_list, currency=Config.CURRENCY)

@commandes_bp.route('/view/<string:order_id>')
@login_required
def view_order(order_id):
    # Extraire la date et l'ID client de l'ID de commande
    date_str, client_id = order_id.split('_')
    date = datetime.strptime(date_str, '%Y-%m-%d')
    
    # Filtrer les ventes pour cette commande
    if client_id == 'guest':
        sales = Sale.query.filter(
            Sale.date >= date,
            Sale.date < date + timedelta(days=1),
            Sale.client_id == None
        ).all()
        client = None
    else:
        sales = Sale.query.filter(
            Sale.date >= date,
            Sale.date < date + timedelta(days=1),
            Sale.client_id == int(client_id)
        ).all()
        client = Client.query.get(int(client_id))
    
    total = sum(sale.total for sale in sales)
    
    return render_template('view_order.html', 
                          order_id=order_id,
                          date=date,
                          client=client,
                          sales=sales,
                          total=total,
                          currency=Config.CURRENCY)
