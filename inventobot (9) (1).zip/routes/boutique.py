from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from flask_login import login_required
from models.product import Product
from models.sale import Sale
from models.client import Client
from models.notification import Notification
from database import db_session
from config import Config

boutique_bp = Blueprint('boutique', __name__, url_prefix='/boutique')

@boutique_bp.route('/')
@login_required
def index():
    products = Product.query.filter(Product.quantity > 0).all()
    
    # Initialiser le panier s'il n'existe pas
    if 'cart' not in session:
        session['cart'] = []
    
    return render_template('boutique.html', products=products, currency=Config.CURRENCY)

@boutique_bp.route('/add_to_cart/<int:product_id>')
@login_required
def add_to_cart(product_id):
    product = Product.query.get_or_404(product_id)
    
    # Récupérer le panier actuel
    cart = session.get('cart', [])
    
    # Vérifier si le produit est déjà dans le panier
    for item in cart:
        if item['id'] == product_id:
            item['quantity'] += 1
            session['cart'] = cart
            flash(f'{product.name} ajouté au panier!', 'success')
            return redirect(url_for('boutique.index'))
    
    # Ajouter le produit au panier
    cart.append({
        'id': product_id,
        'name': product.name,
        'price': product.price,
        'quantity': 1
    })
    
    session['cart'] = cart
    flash(f'{product.name} ajouté au panier!', 'success')
    return redirect(url_for('boutique.index'))

@boutique_bp.route('/remove_from_cart/<int:product_id>')
@login_required
def remove_from_cart(product_id):
    cart = session.get('cart', [])
    
    # Filtrer le panier pour supprimer le produit
    cart = [item for item in cart if item['id'] != product_id]
    
    session['cart'] = cart
    flash('Produit retiré du panier!', 'success')
    return redirect(url_for('boutique.cart'))

@boutique_bp.route('/cart')
@login_required
def cart():
    cart = session.get('cart', [])
    total = sum(item['price'] * item['quantity'] for item in cart)
    
    return render_template('cart.html', cart=cart, total=total, currency=Config.CURRENCY)

@boutique_bp.route('/checkout', methods=['GET', 'POST'])
@login_required
def checkout():
    cart = session.get('cart', [])
    
    if not cart:
        flash('Votre panier est vide!', 'danger')
        return redirect(url_for('boutique.index'))
    
    if request.method == 'POST':
        client_id = request.form.get('client_id')
        client = None
        
        if client_id and client_id != '0':
            client = Client.query.get(client_id)
        
        # Créer une vente pour chaque produit dans le panier
        for item in cart:
            product = Product.query.get(item['id'])
            
            if product.quantity < item['quantity']:
                flash(f'Stock insuffisant pour {product.name}!', 'danger')
                return redirect(url_for('boutique.cart'))
            
            # Créer la vente
            sale = Sale(
                product_id=product.id,
                client_id=client.id if client else None,
                quantity=item['quantity'],
                price=product.price,
                total=product.price * item['quantity']
            )
            
            # Mettre à jour le stock
            product.quantity -= item['quantity']
            
            # Mettre à jour les dépenses du client
            if client:
                client.total_spent += sale.total
            
            db_session.add(sale)
        
        db_session.commit()
        
        # Vider le panier
        session['cart'] = []
        
        Notification.create(
            title="Commande effectuée",
            message="Votre commande a été effectuée avec succès.",
            type="success"
        )
        
        flash('Commande effectuée avec succès!', 'success')
        return redirect(url_for('boutique.index'))
    
    # Récupérer la liste des clients pour le formulaire
    clients = Client.query.all()
    total = sum(item['price'] * item['quantity'] for item in cart)
    
    return render_template('checkout.html', cart=cart, clients=clients, total=total, currency=Config.CURRENCY)
