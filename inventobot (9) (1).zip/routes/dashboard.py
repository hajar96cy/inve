from flask import Blueprint, render_template
from flask_login import login_required
from models.product import Product
from models.sale import Sale
from models.client import Client
from sqlalchemy import func
from database import db_session

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/dashboard')
@login_required
def index():
    # Statistiques pour le tableau de bord
    product_count = Product.query.count()
    client_count = Client.query.count()
    
    # Total des ventes
    sales_total = db_session.query(func.sum(Sale.total)).scalar() or 0
    
    # Valeur du stock
    stock_value = db_session.query(func.sum(Product.price * Product.quantity)).scalar() or 0
    
    # Dernières ventes
    recent_sales = Sale.query.order_by(Sale.date.desc()).limit(5).all()
    
    # Produits à faible stock
    low_stock_products = Product.query.filter(Product.quantity < 10).all()
    
    return render_template('dashboard.html', 
                          product_count=product_count,
                          client_count=client_count,
                          sales_total=sales_total,
                          stock_value=stock_value,
                          recent_sales=recent_sales,
                          low_stock_products=low_stock_products)
