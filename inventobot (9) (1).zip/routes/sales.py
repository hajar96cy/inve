from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required
from models.sale import Sale
from models.product import Product
from models.client import Client
from models.notification import Notification
from database import db_session
from datetime import datetime
from config import Config

sales_bp = Blueprint('sales', __name__, url_prefix='/sales')

@sales_bp.route('/')
@login_required
def list_sales():
    sales = Sale.query.order_by(Sale.date.desc()).all()
    return render_template('sales/list.html', sales=sales, currency=Config.CURRENCY)

@sales_bp.route('/add', methods=['GET', 'POST'])
@login_required
def add_sale():
    if request.method == 'POST':
        product_id = request.form.get('product_id')
        client_id = request.form.get('client_id')
        quantity = int(request.form.get('quantity'))
        
        product = Product.query.get_or_404(product_id)
        
        if product.quantity < quantity:
            flash('Stock insuffisant!', 'danger')
            return redirect(url_for('sales.add_sale'))
        
        # Créer la vente
        sale = Sale(
            product_id=product_id,
            client_id=client_id if client_id and client_id != '0' else None,
            quantity=quantity,
            price=product.price,
            total=product.price * quantity
        )
        
        # Mettre à jour le stock
        product.quantity -= quantity
        
        # Mettre à jour les dépenses du client
        if client_id and client_id != '0':
            client = Client.query.get(client_id)
            client.total_spent += sale.total
        
        db_session.add(sale)
        db_session.commit()
        
        Notification.create(
            title="Vente ajoutée",
            message=f"Une vente de {quantity} {product.name} a été enregistrée.",
            type="success"
        )
        
        flash('Vente ajoutée avec succès!', 'success')
        return redirect(url_for('sales.list_sales'))
    
    products = Product.query.filter(Product.quantity > 0).all()
    clients = Client.query.all()
    
    return render_template('sales/add.html', products=products, clients=clients)

@sales_bp.route('/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_sale(id):
    sale = Sale.query.get_or_404(id)
    
    if request.method == 'POST':
        new_quantity = int(request.form.get('quantity'))
        product = Product.query.get(sale.product_id)
        
        # Calculer la différence de quantité
        quantity_diff = new_quantity - sale.quantity
        
        # Vérifier si le stock est suffisant
        if quantity_diff > 0 and product.quantity < quantity_diff:
            flash('Stock insuffisant pour cette modification!', 'danger')
            return redirect(url_for('sales.edit_sale', id=id))
        
        # Mettre à jour le stock
        product.quantity -= quantity_diff
        
        # Mettre à jour la vente
        sale.quantity = new_quantity
        sale.total = sale.price * new_quantity
        
        # Mettre à jour les dépenses du client
        if sale.client_id:
            client = Client.query.get(sale.client_id)
            client.total_spent = client.total_spent - (sale.price * quantity_diff) + sale.total
        
        db_session.commit()
        
        Notification.create(
            title="Vente modifiée",
            message=f"La vente #{sale.id} a été modifiée.",
            type="info"
        )
        
        flash('Vente modifiée avec succès!', 'success')
        return redirect(url_for('sales.list_sales'))
    
    products = Product.query.all()
    clients = Client.query.all()
    
    return render_template('sales/edit.html', sale=sale, products=products, clients=clients)

@sales_bp.route('/delete/<int:id>')
@login_required
def delete_sale(id):
    sale = Sale.query.get_or_404(id)
    
    # Remettre les produits en stock
    product = Product.query.get(sale.product_id)
    product.quantity += sale.quantity
    
    # Mettre à jour les dépenses du client
    if sale.client_id:
        client = Client.query.get(sale.client_id)
        client.total_spent -= sale.total
    
    db_session.delete(sale)
    db_session.commit()
    
    Notification.create(
        title="Vente supprimée",
        message=f"La vente #{id} a été supprimée.",
        type="warning"
    )
    
    flash('Vente supprimée avec succès!', 'success')
    return redirect(url_for('sales.list_sales'))
