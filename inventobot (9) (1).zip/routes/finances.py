from flask import Blueprint, render_template
from flask_login import login_required
from models.sale import Sale
from sqlalchemy import func, extract
from database import db_session
from datetime import datetime
from config import Config

finances_bp = Blueprint('finances', __name__, url_prefix='/finances')

@finances_bp.route('/')
@login_required
def index():
    # Chiffre d'affaires total
    total_revenue = db_session.query(func.sum(Sale.total)).scalar() or 0
    
    # Chiffre d'affaires par mois (pour l'année en cours)
    current_year = datetime.now().year
    monthly_revenue = db_session.query(
        extract('month', Sale.date).label('month'),
        func.sum(Sale.total).label('total')
    ).filter(
        extract('year', Sale.date) == current_year
    ).group_by('month').all()
    
    # Formater les données pour le graphique
    months = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 
              'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre']
    
    chart_data = [0] * 12
    for month, total in monthly_revenue:
        chart_data[int(month) - 1] = float(total)
    
    # Coûts estimés (exemple: 50% du chiffre d'affaires)
    estimated_costs = total_revenue * 0.5
    
    # Bénéfice brut
    gross_profit = total_revenue - estimated_costs
    
    return render_template('finances.html', 
                          total_revenue=total_revenue,
                          estimated_costs=estimated_costs,
                          gross_profit=gross_profit,
                          months=months,
                          chart_data=chart_data,
                          currency=Config.CURRENCY)
