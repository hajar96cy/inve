from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required
from models.sale import Sale
from models.client import Client
from database import db_session
from datetime import datetime, timedelta
from config import Config

factures_bp = Blueprint('factures', __name__, url_prefix='/factures')

@factures_bp.route('/')
@login_required
def index():
    # Similaire à commandes, mais avec plus d'informations financières
    sales = Sale.query.order_by(Sale.date.desc()).all()
    
    # Créer un dictionnaire pour regrouper les ventes par mois et client
    invoices = {}
    for sale in sales:
        # Clé: mois + année + client_id
        key = f"{sale.date.strftime('%Y-%m')}_{sale.client_id or 'guest'}"
        
        if key not in invoices:
            invoices[key] = {
                'id': key,
                'month': sale.date.strftime('%B %Y'),
                'client': sale.client.name if sale.client else "Client anonyme",
                'client_id': sale.client_id,
                'items': [],
                'total': 0
            }
        
        invoices[key]['items'].append({
            'product': sale.product.name,
            'quantity': sale.quantity,
            'price': sale.price,
            'total': sale.total
        })
        
        invoices[key]['total'] += sale.total
    
    # Convertir le dictionnaire en liste
    invoices_list = list(invoices.values())
    
    return render_template('factures.html', invoices=invoices_list, currency=Config.CURRENCY)

@factures_bp.route('/view/<string:invoice_id>')
@login_required
def view_invoice(invoice_id):
    # Extraire le mois/année et l'ID client de l'ID de facture
    month_year, client_id = invoice_id.split('_')
    year, month = month_year.split('-')
    
    # Calculer la date de début et de fin du mois
    start_date = datetime(int(year), int(month), 1)
    if int(month) == 12:
        end_date = datetime(int(year) + 1, 1, 1)
    else:
        end_date = datetime(int(year), int(month) + 1, 1)
    
    # Filtrer les ventes pour cette facture
    if client_id == 'guest':
        sales = Sale.query.filter(
            Sale.date >= start_date,
            Sale.date < end_date,
            Sale.client_id == None
        ).all()
        client = None
    else:
        sales = Sale.query.filter(
            Sale.date >= start_date,
            Sale.date < end_date,
            Sale.client_id == int(client_id)
        ).all()
        client = Client.query.get(int(client_id))
    
    total = sum(sale.total for sale in sales)
    
    return render_template('view_invoice.html', 
                          invoice_id=invoice_id,
                          month_year=start_date.strftime('%B %Y'),
                          client=client,
                          sales=sales,
                          total=total,
                          currency=Config.CURRENCY)
