from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required
from models.client import Client
from models.sale import Sale
from models.notification import Notification
from database import db_session
from config import Config

clients_bp = Blueprint('clients', __name__, url_prefix='/clients')

@clients_bp.route('/')
@login_required
def list_clients():
    clients = Client.query.all()
    return render_template('clients/list.html', clients=clients, currency=Config.CURRENCY)

@clients_bp.route('/add', methods=['GET', 'POST'])
@login_required
def add_client():
    if request.method == 'POST':
        name = request.form.get('name')
        phone = request.form.get('phone')
        address = request.form.get('address')
        email = request.form.get('email')
        
        client = Client(name=name, phone=phone, address=address, email=email)
        db_session.add(client)
        db_session.commit()
        
        Notification.create(
            title="Client ajouté",
            message=f"Le client {name} a été ajouté avec succès.",
            type="success"
        )
        
        flash('Client ajouté avec succès!', 'success')
        return redirect(url_for('clients.list_clients'))
        
    return render_template('clients/add.html')

@clients_bp.route('/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_client(id):
    client = Client.query.get_or_404(id)
    
    if request.method == 'POST':
        client.name = request.form.get('name')
        client.phone = request.form.get('phone')
        client.address = request.form.get('address')
        client.email = request.form.get('email')
        
        db_session.commit()
        
        Notification.create(
            title="Client mis à jour",
            message=f"Le client {client.name} a été mis à jour.",
            type="info"
        )
        
        flash('Client mis à jour avec succès!', 'success')
        return redirect(url_for('clients.list_clients'))
        
    return render_template('clients/edit.html', client=client)

@clients_bp.route('/delete/<int:id>')
@login_required
def delete_client(id):
    client = Client.query.get_or_404(id)
    client_name = client.name
    
    # Vérifier si le client a des ventes
    sales = Sale.query.filter_by(client_id=id).first()
    if sales:
        flash('Impossible de supprimer ce client car il a des ventes associées!', 'danger')
        return redirect(url_for('clients.list_clients'))
    
    db_session.delete(client)
    db_session.commit()
    
    Notification.create(
        title="Client supprimé",
        message=f"Le client {client_name} a été supprimé.",
        type="warning"
    )
    
    flash('Client supprimé avec succès!', 'success')
    return redirect(url_for('clients.list_clients'))

@clients_bp.route('/view/<int:id>')
@login_required
def view_client(id):
    client = Client.query.get_or_404(id)
    sales = Sale.query.filter_by(client_id=id).order_by(Sale.date.desc()).all()
    
    return render_template('clients/view.html', client=client, sales=sales, currency=Config.CURRENCY)
