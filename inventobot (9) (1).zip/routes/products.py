from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required
from models.product import Product
from models.sale import Sale
from models.notification import Notification
from database import db_session

products_bp = Blueprint('products', __name__, url_prefix='/products')

@products_bp.route('/')
@login_required
def list_products():
    products = Product.query.all()
    return render_template('products/list.html', products=products)

@products_bp.route('/add', methods=['GET', 'POST'])
@login_required
def add_product():
    if request.method == 'POST':
        name = request.form.get('name')
        description = request.form.get('description')
        price = float(request.form.get('price'))
        quantity = int(request.form.get('quantity'))
        
        product = Product(name=name, description=description, price=price, quantity=quantity)
        db_session.add(product)
        db_session.commit()
        
        Notification.create(
            title="Produit ajouté",
            message=f"Le produit {name} a été ajouté avec succès.",
            type="success"
        )
        
        flash('Produit ajouté avec succès!', 'success')
        return redirect(url_for('products.list_products'))
        
    return render_template('products/add.html')

@products_bp.route('/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_product(id):
    product = Product.query.get_or_404(id)
    
    if request.method == 'POST':
        product.name = request.form.get('name')
        product.description = request.form.get('description')
        product.price = float(request.form.get('price'))
        product.quantity = int(request.form.get('quantity'))
        
        db_session.commit()
        
        Notification.create(
            title="Produit mis à jour",
            message=f"Le produit {product.name} a été mis à jour.",
            type="info"
        )
        
        flash('Produit mis à jour avec succès!', 'success')
        return redirect(url_for('products.list_products'))
        
    return render_template('products/edit.html', product=product)

@products_bp.route('/delete/<int:id>')
@login_required
def delete_product(id):
    product = Product.query.get_or_404(id)
    product_name = product.name
    
    # Vérifier si le produit a des ventes
    sales = Sale.query.filter_by(product_id=id).first()
    if sales:
        flash('Impossible de supprimer ce produit car il a des ventes associées!', 'danger')
        return redirect(url_for('products.list_products'))
    
    db_session.delete(product)
    db_session.commit()
    
    Notification.create(
        title="Produit supprimé",
        message=f"Le produit {product_name} a été supprimé.",
        type="warning"
    )
    
    flash('Produit supprimé avec succès!', 'success')
    return redirect(url_for('products.list_products'))
