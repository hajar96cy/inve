"use client"

import type React from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

interface Client {
  id: number
  nom: string
  telephone: string
  adresse: string
  depenses: number
}

interface ClientTableProps {
  clients: Client[]
}

const ClientTable: React.FC<ClientTableProps> = ({ clients }) => {
  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>ID</TableHead>
            <TableHead>Nom</TableHead>
            <TableHead>Téléphone</TableHead>
            <TableHead>Adresse</TableHead>
            <TableHead>Dépenses</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {clients.map((client) => (
            <TableRow key={client.id}>
              <TableCell className="font-medium">{client.id}</TableCell>
              <TableCell>{client.nom}</TableCell>
              <TableCell>{client.telephone}</TableCell>
              <TableCell>{client.adresse}</TableCell>
              <TableCell>{client.depenses.toFixed(2)} Dh</TableCell>
              <TableCell>
                <div className="flex space-x-2">
                  <button
                    className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-1 px-2 rounded text-xs"
                    onClick={() => console.log("Voir client", client.id)}
                  >
                    Voir
                  </button>
                  <button
                    className="bg-yellow-500 hover:bg-yellow-700 text-white font-bold py-1 px-2 rounded text-xs"
                    onClick={() => console.log("Modifier client", client.id)}
                  >
                    Modifier
                  </button>
                  <button
                    className="bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-2 rounded text-xs"
                    onClick={() => console.log("Supprimer client", client.id)}
                  >
                    Supprimer
                  </button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

export default ClientTable
