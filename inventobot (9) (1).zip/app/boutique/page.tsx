"use client"

import { useState, useEffect } from "react"
import { useCart } from "@/context/cart"
import { useRouter } from "next/navigation"

const products = [
  { id: 1, name: "T-shirt", price: 25 },
  { id: 2, name: "Mug", price: 15 },
  { id: 3, name: "Poster", price: 10 },
]

const ActionButton = ({ children, ...props }) => (
  <button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded" {...props}>
    {children}
  </button>
)

const Product = ({ product, onAddToCart }) => (
  <div className="border p-4">
    <h2 className="text-xl font-bold">{product.name}</h2>
    <p className="text-xl font-bold">{product.price.toFixed(2)} Dh</p>
    <ActionButton onClick={() => onAddToCart(product)}>Ajouter au panier</ActionButton>
  </div>
)

const BoutiquePage = () => {
  const { cart, addToCart, removeFromCart, clearCart } = useCart()
  const [cartTotal, setCartTotal] = useState(0)
  const router = useRouter()

  useEffect(() => {
    const total = cart.reduce((acc, item) => acc + item.price * item.quantity, 0)
    setCartTotal(total)
  }, [cart])

  const handleAddToCart = (product) => {
    addToCart(product)
  }

  const handleRemoveFromCart = (productId) => {
    removeFromCart(productId)
  }

  const handleClearCart = () => {
    clearCart()
  }

  const handleCheckout = () => {
    alert("Checkout functionality not implemented yet.")
  }

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Boutique</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
        {products.map((product) => (
          <Product key={product.id} product={product} onAddToCart={handleAddToCart} />
        ))}
      </div>

      <h2 className="text-xl font-bold mb-2">Panier</h2>
      {cart.length === 0 ? (
        <p>Votre panier est vide.</p>
      ) : (
        <>
          <table className="table-auto w-full mb-4">
            <thead>
              <tr>
                <th className="text-left">Produit</th>
                <th className="text-left">Prix</th>
                <th className="text-left">Quantité</th>
                <th className="text-left">Total</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {cart.map((item) => (
                <tr key={item.id}>
                  <td className="py-3">{item.name}</td>
                  <td className="py-3">{item.price.toFixed(2)} Dh</td>
                  <td className="py-3">{item.quantity}</td>
                  <td className="py-3">{(item.price * item.quantity).toFixed(2)} Dh</td>
                  <td className="py-3">
                    <ActionButton onClick={() => handleRemoveFromCart(item.id)}>Supprimer</ActionButton>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="flex justify-between items-center">
            <p className="text-xl font-bold">Total: {cartTotal.toFixed(2)} Dh</p>
            <div>
              <ActionButton onClick={handleClearCart} className="mr-2">
                Vider le panier
              </ActionButton>
              <ActionButton type="submit">Passer la commande ({cartTotal.toFixed(2)} Dh)</ActionButton>
            </div>
          </div>
        </>
      )}
    </div>
  )
}

export default BoutiquePage
