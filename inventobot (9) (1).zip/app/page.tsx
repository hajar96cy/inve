import Loading from "./boutique/loading"

export default function Page() {
  return <Loading />
}
