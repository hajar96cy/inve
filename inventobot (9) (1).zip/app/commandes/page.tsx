"use client"

import { useState, useEffect } from "react"

interface Order {
  id: number
  date: string
  client: string
  produits: string
  prix: number
  statut: string
}

const CommandesPage = () => {
  const [orders, setOrders] = useState<Order[]>([])

  useEffect(() => {
    // Fetch orders from API or any data source
    const fetchOrders = async () => {
      // Replace this with your actual data fetching logic
      const mockOrders: Order[] = [
        { id: 1, date: "2024-01-01", client: "Client A", produits: "Produit X", prix: 100.0, statut: "En cours" },
        { id: 2, date: "2024-01-05", client: "Client B", produits: "Produit Y", prix: 150.5, statut: "Livrée" },
        { id: 3, date: "2024-01-10", client: "Client C", produits: "Produit Z", prix: 75.25, statut: "Annulée" },
      ]
      setOrders(mockOrders)
    }

    fetchOrders()
  }, [])

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-4">Commandes</h1>
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white border border-gray-300">
          <thead>
            <tr>
              <th className="py-2 px-4 border-b">ID</th>
              <th className="py-2 px-4 border-b">Date</th>
              <th className="py-2 px-4 border-b">Client</th>
              <th className="py-2 px-4 border-b">Produits</th>
              <th className="py-2 px-4 border-b">Prix</th>
              <th className="py-2 px-4 border-b">Statut</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <tr key={order.id}>
                <td className="py-3 px-4 border-b">{order.id}</td>
                <td className="py-3 px-4 border-b">{order.date}</td>
                <td className="py-3 px-4 border-b">{order.client}</td>
                <td className="py-3 px-4 border-b">{order.produits}</td>
                <td className="py-3">{order.prix.toFixed(2)} Dh</td>
                <td className="py-3 px-4 border-b">{order.statut}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default CommandesPage
