interface Invoice {
  id: number
  montant: number
  date: string
  client: string
}

const invoices: Invoice[] = [
  { id: 1, montant: 100, date: "2023-01-01", client: "Client A" },
  { id: 2, montant: 200, date: "2023-01-05", client: "Client B" },
  { id: 3, montant: 150, date: "2023-01-10", client: "Client C" },
]

const FacturesPage = () => {
  return (
    <div>
      <h1>Factures</h1>
      <ul>
        {invoices.map((invoice) => (
          <li key={invoice.id}>
            <div>ID: {invoice.id}</div>
            <div>Montant: {invoice.montant.toFixed(2)} Dh</div>
            <div>Date: {invoice.date}</div>
            <div>Client: {invoice.client}</div>
          </li>
        ))}
      </ul>
    </div>
  )
}

export default FacturesPage
