import ClientTable from "@/components/ClientTable"

const ClientsPage = () => {
  const clients = [
    {
      id: 1,
      nom: "Client A",
      telephone: "123-456-7890",
      adresse: "123 Main St",
      depenses: 150.5,
    },
    {
      id: 2,
      nom: "Client B",
      telephone: "987-654-3210",
      adresse: "456 Oak Ave",
      depenses: 220.75,
    },
    {
      id: 3,
      nom: "Client C",
      telephone: "555-123-4567",
      adresse: "789 Pine Ln",
      depenses: 85.2,
    },
  ]

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-4">Clients</h1>
      <ClientTable clients={clients} />
    </div>
  )
}

export default ClientsPage
