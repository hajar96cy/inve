"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { PlusIcon } from "@heroicons/react/24/solid"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface Sale {
  id: number
  product: string
  quantity: number
  price: number
  total: number
}

interface StatCardProps {
  title: string
  value: string
  bgColor: string
}

const StatCard: React.FC<StatCardProps> = ({ title, value, bgColor }) => {
  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className={`rounded-full p-3 ${bgColor} w-fit`}>{/* Icon here */}</div>
        <p className="text-2xl font-bold">{value}</p>
      </CardContent>
    </Card>
  )
}

const StockPage = () => {
  const [sales, setSales] = useState<Sale[]>([])
  const [newSale, setNewSale] = useState({
    product: "",
    quantity: 0,
    price: 0,
  })
  const [stockValue, setStockValue] = useState(0)
  const { toast } = useToast()

  useEffect(() => {
    // Mock data for demonstration
    const initialSales: Sale[] = [
      { id: 1, product: "Product A", quantity: 10, price: 25, total: 250 },
      { id: 2, product: "Product B", quantity: 5, price: 50, total: 250 },
      { id: 3, product: "Product C", quantity: 15, price: 15, total: 225 },
    ]
    setSales(initialSales)
    calculateStockValue(initialSales)
  }, [])

  const calculateStockValue = (salesData: Sale[]) => {
    const totalValue = salesData.reduce((acc, sale) => acc + sale.total, 0)
    setStockValue(totalValue)
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setNewSale({ ...newSale, [e.target.name]: e.target.value })
  }

  const addSale = () => {
    if (!newSale.product || !newSale.quantity || !newSale.price) {
      toast({
        title: "Error",
        description: "Please fill in all fields.",
        variant: "destructive",
      })
      return
    }

    const newSaleItem: Sale = {
      id: sales.length + 1,
      product: newSale.product,
      quantity: Number.parseInt(newSale.quantity.toString()),
      price: Number.parseFloat(newSale.price.toString()),
      total: Number.parseInt(newSale.quantity.toString()) * Number.parseFloat(newSale.price.toString()),
    }

    setSales([...sales, newSaleItem])
    calculateStockValue([...sales, newSaleItem])
    setNewSale({ product: "", quantity: 0, price: 0 })

    toast({
      title: "Success",
      description: "Sale added successfully.",
    })
  }

  return (
    <div className="container mx-auto py-10">
      <h1 className="text-3xl font-bold mb-5">Stock Management</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-5">
        <StatCard title="Nombre de produits" value="30" bgColor="bg-blue-50" />
        <StatCard title="Ventes totales" value="150" bgColor="bg-yellow-50" />
        <StatCard title="Valeur de stock" value={`${stockValue.toFixed(2)} Dh`} bgColor="bg-green-50" />
      </div>

      <Card className="shadow-md">
        <CardHeader>
          <CardTitle>Sales History</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Product</TableHead>
                <TableHead>Quantity</TableHead>
                <TableHead>Price</TableHead>
                <TableHead>Total</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sales.map((sale) => (
                <TableRow key={sale.id}>
                  <TableCell className="font-medium">{sale.product}</TableCell>
                  <TableCell className="py-3">{sale.quantity}</TableCell>
                  <TableCell className="py-3">{sale.price.toFixed(2)} Dh</TableCell>
                  <TableCell className="py-3">{sale.total.toFixed(2)} Dh</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Sheet>
        <SheetTrigger asChild>
          <Button variant="outline" className="mt-5">
            <PlusIcon className="mr-2 h-4 w-4" /> Add Sale
          </Button>
        </SheetTrigger>
        <SheetContent className="sm:max-w-md">
          <SheetHeader>
            <SheetTitle>Add New Sale</SheetTitle>
            <SheetDescription>Add a new sale to update the stock and total value.</SheetDescription>
          </SheetHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="product" className="text-right">
                Product
              </Label>
              <Input
                type="text"
                id="product"
                name="product"
                value={newSale.product}
                onChange={handleInputChange}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="quantity" className="text-right">
                Quantity
              </Label>
              <Input
                type="number"
                id="quantity"
                name="quantity"
                value={newSale.quantity}
                onChange={(e) =>
                  setNewSale({
                    ...newSale,
                    quantity: Number.parseInt(e.target.value),
                  })
                }
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="price" className="text-right">
                Price
              </Label>
              <Input
                type="number"
                id="price"
                name="price"
                value={newSale.price}
                onChange={(e) =>
                  setNewSale({
                    ...newSale,
                    price: Number.parseFloat(e.target.value),
                  })
                }
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="total" className="text-right">
                Total
              </Label>
              <Input
                type="text"
                value={`${(newSale.quantity * newSale.price).toFixed(2)} Dh`}
                readOnly
                className="bg-gray-50"
              />
            </div>
          </div>
          <Button type="submit" onClick={addSale}>
            Add Sale
          </Button>
        </SheetContent>
      </Sheet>
    </div>
  )
}

export default StockPage
