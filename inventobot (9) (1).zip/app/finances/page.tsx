import type React from "react"

interface StatCardProps {
  title: string
  value: string
  bgColor: string
}

const StatCard: React.FC<StatCardProps> = ({ title, value, bgColor }) => {
  return (
    <div className={`p-4 rounded-lg shadow-md ${bgColor}`}>
      <h3 className="text-lg font-semibold text-gray-700">{title}</h3>
      <p className="text-2xl font-bold text-gray-900">{value}</p>
    </div>
  )
}

const FinancesPage = () => {
  // Dummy data for demonstration
  const totalRevenue = 150000
  const estimatedCosts = 75000
  const grossProfit = totalRevenue - estimatedCosts

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-4">Finances</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <StatCard title="Chiffre d'affaires" value={`${totalRevenue.toFixed(2)} Dh`} bgColor="bg-blue-50" />
        <StatCard title="Coûts estimés" value={`${estimatedCosts.toFixed(2)} Dh`} bgColor="bg-purple-50" />
        <StatCard title="Bénéfice brut" value={`${grossProfit.toFixed(2)} Dh`} bgColor="bg-green-50" />
      </div>

      <div className="mt-8">
        <h2 className="text-2xl font-semibold mb-2">Détails Financiers</h2>
        <p>Informations détaillées sur les finances de l'entreprise en Dh.</p>
        {/* Add more detailed financial information here */}
      </div>
    </div>
  )
}

export default FinancesPage
