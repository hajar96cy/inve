// Fonctions JavaScript communes pour InventoBot

// Fonction pour formater les nombres en monnaie
function formatCurrency(amount, currency = "Dh") {
  return amount.toFixed(2) + " " + currency
}

// Fonction pour confirmer les suppressions
function confirmDelete(message = "Êtes-vous sûr de vouloir supprimer cet élément ?") {
  return confirm(message)
}

// Initialisation des tooltips Bootstrap
document.addEventListener("DOMContentLoaded", () => {
  var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
  var tooltipList = tooltipTriggerList.map((tooltipTriggerEl) => {
    return new bootstrap.Tooltip(tooltipTriggerEl)
  })
  const bootstrap = window.bootstrap
})
